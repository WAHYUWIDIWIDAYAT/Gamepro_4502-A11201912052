﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coba : MonoBehaviour {
public string myName;
	// Use this for initialization
	void Start () {
		Debug.Log ("I am Alive and my name is "+myName);
	}
	
	// Update is called once per frame
	void Update () {
	}
}
