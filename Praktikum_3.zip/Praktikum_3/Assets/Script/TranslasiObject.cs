﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TranslasiObject : MonoBehaviour {

	// Use this for initialization
	public int speed;
	Vector3 kekiri;
	void Start () {
		kekiri = new Vector3(-1,0,0);
	}
	
	// Update is called once per frame
	void Update () {
		transform.position = transform.position + (kekiri * speed * Time.deltaTime);
	}
}
